
// FIREBASE DISABLED FOR UI TESTING
// This file is currently empty to prevent connection errors in the preview environment.
// To reconnect: Uncomment the firebase initialization code when ready for backend development.

export const db = {} as any;

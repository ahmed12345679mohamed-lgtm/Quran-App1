
import { DailyLog, Grade } from '../types';

// التحيات الافتتاحية
const GREETINGS = [
  "السلام عليكم ورحمة الله وبركاته، حياكم الله ولي أمر الطالب المجتهد {name} 🌹",
  "تحية طيبة مباركة، نرسل إليكم تقرير بطلنا القرآني {name} لهذا اليوم 🌙",
  "أهلاً بكم ولي أمر الطالب {name}، إليكم بشرى مستوى ابنكم اليوم في الحلقة 🕌",
  "السلام عليكم، نضع بين أيديكم حصاد اليوم لابننا المبارك {name} 👇"
];

// الرسائل بناءً على التقدير
const BODY_BY_GRADE = {
  [Grade.EXCELLENT]: [
    "بفضل الله، كان أداء {name} اليوم مبهراً وممتازاً! تلاوة متقنة، وحفظ راسخ، وثقة عالية بالنفس. لقد أثلج صدورنا بتميزه.",
    "ما شاء الله لا قوة إلا بالله، مستوى {name} اليوم في القمة. دقة في الأحكام وجمال في التلاوة، وهذا يعكس جهدكم المبارك في المتابعة.",
    "أبدع اليوم في تسميعه، وكان مثالاً للطالب المجتهد. حفظه ممتاز ويستحق كل عبارات الثناء والتقدير."
  ],
  [Grade.VERY_GOOD]: [
    "أداء {name} اليوم جيد جداً ومبشر بالخير. التلاوة طيبة والحفظ مستقر، مع بعض التنبيهات البسيطة التي سيتجاوزها بقليل من المراجعة.",
    "قدم مستوى طيباً اليوم، ونحن فخورون بتقدمه. يحتاج فقط لزيادة بسيطة في التكرار ليصل إلى الامتياز في المرة القادمة بإذن الله.",
    "جهد واضح ومستوى متقدم، بارك الله في همته. نتطلع منه للمزيد من التركيز ليصبح حفظه متقناً تماماً."
  ],
  [Grade.GOOD]: [
    "مستوى {name} اليوم جيد، ولكنه يمتلك قدرات أعلى من ذلك. الحفظ يحتاج لمزيد من التثبيت والمراجعة في المنزل.",
    "أداؤه مقبول، ولكننا نعهده دائماً في المراتب الأولى. نرجو تكثيف المراجعة اليومية ليعود لمستواه المعهود.",
    "بذل جهداً طيباً، لكن التسميع تخلله بعض التردد. نوصي بتخصيص وقت أكبر للتكرار قبل الحصة القادمة."
  ],
  [Grade.ACCEPTABLE]: [
    "مستوى اليوم يحتاج لوقفة واهتمام أكبر. الحفظ كان ضعيفاً بعض الشيء، ونخشى عليه من التفلت إذا لم يتم تداركه.",
    "نلفت انتباهكم أن {name} واجه صعوبة في التسميع اليوم. نرجو منكم متابعته في المنزل لتعويض ما فات.",
    "الأداء اليوم كان مقبولاً بصعوبة. القرآن عزيز ويحتاج لتعاهد، نرجو حثه على الاجتهاد أكثر."
  ],
  [Grade.NEEDS_WORK]: [
    "للأسف، الحفظ اليوم لم يكن جاهزاً ويحتاج لإعادة. نثق بقدرة {name} على التعويض، لكنه يحتاج لدعمكم ومتابعتكم الجادة.",
    "لم يتمكن من التسميع اليوم بشكل صحيح. نرجو التعاون معنا وتكثيف المراجعة في البيت لضمان عدم تأخره عن زملائه."
  ]
};

// الأدعية الخاتمة للوالدين والطالب
const CLOSINGS = [
  "نسأل الله أن يقر أعينكم به، وأن يجعله من حفظة كتابه العاملين به، وجزاكم الله خيراً على حسن متابعتكم. 🤲",
  "بارك الله فيكم وفي ذريتكم، وجعل القرآن شفيعاً لكم وله يوم القيامة. شكراً لاهتمامكم. ✨",
  "اللهم أنبته نباتاً حسناً واجعله قرة عين لوالديه. شكر الله سعيكم وكتب أجركم. 🌷",
  "زادكم الله حرصاً وتوفيقاً، وألبسكم به تاج الوقار يوم القيامة. دمتم في حفظ الله. 💎"
];

const DEFAULT_BODIES = [
    "نسأل الله أن يجعله من أهل القرآن. نرجو الاستمرار في المراجعة والاهتمام بالورد اليومي.",
    "بارك الله في الجهود المبذولة، ننتظر المزيد من التقدم والتركيز في الحصص القادمة.",
];

export const generateEncouragement = async (studentName: string, log: DailyLog): Promise<string> => {
  // 1. اختيار التحية
  const greetingTemplate = GREETINGS[Math.floor(Math.random() * GREETINGS.length)];
  const greeting = greetingTemplate.replace("{name}", studentName);

  // 2. تحديد التقدير واختيار نص الرسالة
  let grade = log.jadeed?.grade;
  
  // If no main grade (e.g. MULTI with undefined top-level), try to find an average or first grade from multiSurahs
  if (!grade && log.jadeed?.type === 'MULTI' && log.jadeed.multiSurahs && log.jadeed.multiSurahs.length > 0) {
      grade = log.jadeed.multiSurahs[0].grade;
  }

  if ((!grade || grade === undefined) && log.murajaah && log.murajaah.length > 0) {
      grade = log.murajaah[0].grade;
      if (!grade && log.murajaah[0].type === 'MULTI' && log.murajaah[0].multiSurahs) {
          grade = log.murajaah[0].multiSurahs[0]?.grade;
      }
  }

  let bodyTemplate = "";
  if (!grade) {
      bodyTemplate = DEFAULT_BODIES[Math.floor(Math.random() * DEFAULT_BODIES.length)];
  } else {
      const bodies = BODY_BY_GRADE[grade] || DEFAULT_BODIES;
      bodyTemplate = bodies[Math.floor(Math.random() * bodies.length)];
  }
  const body = bodyTemplate.replace("{name}", studentName);

  // 3. اختيار الخاتمة والدعاء
  const closing = CLOSINGS[Math.floor(Math.random() * CLOSINGS.length)];

  // تجميع الرسالة
  return `${greeting}\n\n${body}\n\n${closing}`;
};
